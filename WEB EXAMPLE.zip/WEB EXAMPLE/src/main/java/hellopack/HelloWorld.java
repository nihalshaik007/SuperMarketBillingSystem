package hellopack;

import javax.xml.ws.*;

@WebService
public class HelloWorld

{

}
